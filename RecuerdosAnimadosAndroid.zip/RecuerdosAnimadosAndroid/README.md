# Recuerdos Animados — Proyecto Android

Proyecto Android nativo que empaqueta el prototipo web local en un WebView. El catálogo funciona sin conexión; los enlaces de canales y búsquedas de YouTube se abren en la aplicación externa correspondiente.

## Abrir en Android Studio
1. Descomprime `RecuerdosAnimadosAndroid.zip`.
2. En Android Studio selecciona **Open** y elige la carpeta `RecuerdosAnimadosAndroid`.
3. Espera a que Gradle sincronice. Se requiere Android Studio compatible con Android Gradle Plugin 8.7.3, JDK 17 y Android SDK 35.
4. Conecta el teléfono con depuración USB habilitada o usa un emulador.
5. Pulsa **Run** para instalar la aplicación de prueba.

## Generar APK
En Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**. El APK de depuración se genera normalmente en `app/build/outputs/apk/debug/app-debug.apk`.

También se puede compilar desde terminal con `gradle assembleDebug` si Gradle y el SDK Android están configurados.

## Estado y límites
- Es un primer proyecto Android de prueba, no una versión lista para publicar.
- No incluye todavía cuentas reales, pagos, suscripciones ni servidor.
- No aloja episodios. Los botones llevan a enlaces de YouTube y búsquedas externas.
- El enlace de Los Pitufos se conserva, pero el usuario reportó errores de reproducción al abrir desde el prototipo; debe volver a probarse dentro de esta app.
- Antes de distribuir episodios completos se necesitan licencias o autorización de los titulares.
